var total = 3;
function addone() {
  total++;
  document.getElementById("likes").innerText = total;
}
